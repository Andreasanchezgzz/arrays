// Ejercicio 4: Encontrando el Primer Escudo con Poder Suficiente
// Instrucciones: Encuentra el primer escudo con un nivel de resistencia mayor a 75.
const escudos = [20, 60, 45, 80, 90, 30];
// Escribe tu solución aquí usando find():
