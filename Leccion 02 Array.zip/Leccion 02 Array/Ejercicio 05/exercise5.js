// Ejercicio 5: Conteo de Espadas Potentes
// Instrucciones: Cuenta cuántas espadas tienen un poder mayor a 50.
const espadas = [20, 60, 45, 80, 90, 30];
// Escribe tu solución aquí usando reduce():
