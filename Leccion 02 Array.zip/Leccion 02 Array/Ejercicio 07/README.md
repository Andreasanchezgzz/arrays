
# Ejercicio 7: Comprobando si Todos los Pergaminos son Legibles

## Descripción
En este ejercicio, debes verificar si todos los pergaminos tienen un valor mayor a 60.

### Instrucciones
- Usa el array proporcionado `pergaminos` para comprobar si todos cumplen la condición.
- Utiliza el método `every()` de JavaScript.

### Objetivo
El objetivo es practicar el método `every()` para validar arrays.

### Archivo a editar
- `exercise7.txt`: Escribe tu solución aquí.

### Comparación
Después de completar tu solución, compara tu respuesta con la solución propuesta en `solution7.txt`.
