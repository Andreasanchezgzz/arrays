
# Ejercicio 1: Filtrando Objetos Mágicos Válidos

## Descripción
En este ejercicio, debes filtrar los objetos mágicos cuyo nivel de poder sea mayor a 50.

### Instrucciones
- Usa el array proporcionado `objetosMagicos` para encontrar aquellos objetos cuyo poder sea superior a 50.
- Utiliza el método `filter()` de JavaScript.

### Objetivo
El objetivo es practicar el método `filter()` en arrays.

### Archivo a editar
- `exercise1.txt`: Escribe tu solución aquí.

### Comparación
Después de completar tu solución, compara tu respuesta con la solución propuesta en `solution1.txt`.
