// Ejercicio 1: Filtrando Objetos Mágicos Válidos
// Instrucciones: Filtra los objetos mágicos cuyo nivel de poder sea mayor a 50.
const objetosMagicos = [20, 60, 45, 80, 90, 30];
// Escribe tu solución aquí usando filter():
