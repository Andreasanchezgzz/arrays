
# Ejercicio 3: Reorganizando los Objetos Mágicos

## Descripción
En este ejercicio, debes invertir el orden de los objetos mágicos.

### Instrucciones
- Usa el array proporcionado `objetosMagicos` para invertir su orden.
- Utiliza el método `reverse()` de JavaScript.

### Objetivo
El objetivo es practicar el método `reverse()` para reorganizar arrays.

### Archivo a editar
- `exercise3.txt`: Escribe tu solución aquí.

### Comparación
Después de completar tu solución, compara tu respuesta con la solución propuesta en `solution3.txt`.
