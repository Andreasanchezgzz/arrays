// Ejercicio 3: Reorganizando los Objetos Mágicos
// Instrucciones: Invierte el orden de los objetos mágicos.
const objetosMagicos = [1, 2, 3, 4, 5];
// Escribe tu solución aquí usando reverse():
