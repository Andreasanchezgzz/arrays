
# Ejercicio 2: Ordenando los Objetos Mágicos

## Descripción
En este ejercicio, debes ordenar los objetos mágicos de mayor a menor poder.

### Instrucciones
- Usa el array proporcionado `objetosMagicos` para ordenarlos en orden descendente.
- Utiliza el método `sort()` de JavaScript.

### Objetivo
El objetivo es practicar el método `sort()` para ordenar arrays.

### Archivo a editar
- `exercise2.txt`: Escribe tu solución aquí.

### Comparación
Después de completar tu solución, compara tu respuesta con la solución propuesta en `solution2.txt`.
