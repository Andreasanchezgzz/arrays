
# Ejercicio 8: Verificando si Algún Hechizo es lo Suficientemente Poderoso

## Descripción
En este ejercicio, debes verificar si al menos un hechizo tiene un poder mayor a 100.

### Instrucciones
- Usa el array proporcionado `hechizos` para comprobar si alguno cumple la condición.
- Utiliza el método `some()` de JavaScript.

### Objetivo
El objetivo es practicar el método `some()` para verificar condiciones en arrays.

### Archivo a editar
- `exercise8.txt`: Escribe tu solución aquí.

### Comparación
Después de completar tu solución, compara tu respuesta con la solución propuesta en `solution8.txt`.
