
# Ejercicio 6: Mapeando los Niveles de Poder de los Anillos de Protección

## Descripción
En este ejercicio, debes multiplicar los niveles de protección de los anillos por 1.5.

### Instrucciones
- Usa el array proporcionado `anillosProteccion` para aumentar el poder de cada anillo.
- Utiliza el método `map()` de JavaScript.

### Objetivo
El objetivo es practicar el método `map()` para transformar arrays.

### Archivo a editar
- `exercise6.txt`: Escribe tu solución aquí.

### Comparación
Después de completar tu solución, compara tu respuesta con la solución propuesta en `solution6.txt`.
