// Ejercicio 6: Mapeando los Niveles de Poder de los Anillos de Protección
// Instrucciones: Multiplica los niveles de protección por 1.5.
const anillosProteccion = [10, 20, 30, 40, 50];
// Escribe tu solución aquí usando map():
