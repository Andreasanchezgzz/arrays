// Solución Ejercicio 7
const pergaminos = [65, 70, 85, 90, 50];
const todosLegibles = pergaminos.every(pergamino => pergamino > 60);
console.log(todosLegibles); // false
