// Solución Ejercicio 4
const escudos = [20, 60, 45, 80, 90, 30];
const primerEscudo = escudos.find(escudo => escudo > 75);
console.log(primerEscudo); // 80
