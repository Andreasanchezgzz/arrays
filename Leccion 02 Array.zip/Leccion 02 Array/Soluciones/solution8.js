// Solución Ejercicio 8
const hechizos = [60, 80, 110, 95, 85];
const hechizoPoderoso = hechizos.some(hechizo => hechizo > 100);
console.log(hechizoPoderoso); // true
