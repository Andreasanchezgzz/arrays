// Solución Ejercicio 3
const objetosMagicos = [1, 2, 3, 4, 5];
const objetosInvertidos = objetosMagicos.reverse();
console.log(objetosInvertidos); // [5, 4, 3, 2, 1]
