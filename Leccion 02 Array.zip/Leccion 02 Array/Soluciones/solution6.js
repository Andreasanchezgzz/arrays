// Solución Ejercicio 6
const anillosProteccion = [10, 20, 30, 40, 50];
const anillosMejorados = anillosProteccion.map(anillo => anillo * 1.5);
console.log(anillosMejorados); // [15, 30, 45, 60, 75]
