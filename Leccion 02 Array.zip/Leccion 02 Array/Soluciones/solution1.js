// Solución Ejercicio 1
const objetosMagicos = [20, 60, 45, 80, 90, 30];
const objetosFiltrados = objetosMagicos.filter(objeto => objeto > 50);
console.log(objetosFiltrados); // [60, 80, 90]
