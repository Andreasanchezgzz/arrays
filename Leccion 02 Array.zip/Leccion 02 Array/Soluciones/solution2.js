// Solución Ejercicio 2
const objetosMagicos = [20, 60, 45, 80, 90, 30];
const objetosOrdenados = objetosMagicos.sort((a, b) => b - a);
console.log(objetosOrdenados); // [90, 80, 60, 45, 30, 20]
